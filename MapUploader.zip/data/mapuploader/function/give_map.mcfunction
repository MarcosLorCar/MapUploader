# map_id, player_id

$execute as @a if score @s MapToken matches $(player_id) run give @s filled_map[map_id=$(map_id)]