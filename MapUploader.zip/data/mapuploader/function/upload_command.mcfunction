scoreboard players reset @s UploadMap

execute unless score @s MapToken matches 1.. store result score @s MapToken run random value 100000..999999

execute store result storage mapuploader:macro_args id int 1 run scoreboard players get @s MapToken

function mapuploader:send_link with storage mapuploader:macro_args