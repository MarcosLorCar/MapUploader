schedule clear mapuploader:tick

scoreboard objectives add UploadMap trigger
scoreboard objectives add MapToken dummy

execute unless data storage mapuploader:macro_args host run data merge storage mapuploader:macro_args {"host":"127.0.0.1"}
execute unless data storage mapuploader:macro_args port run data merge storage mapuploader:macro_args {"port":"8080"}
tellraw @a [{text:"MapUploader datapackp enabled with host: "},{nbt:"host",storage:"mapuploader:macro_args"}, {text:", and port: "}, {nbt:"port",storage:"mapuploader:macro_args"}]

schedule function mapuploader:tick 2t