schedule function mapuploader:tick 2t

scoreboard players enable @a UploadMap
execute if entity @a[scores={UploadMap=1..}] as @a[scores={UploadMap=1..}] run function mapuploader:upload_command with entity @s